package GUI;

import Func.DB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class GRNController implements Initializable {
    DB db=new DB();
    @FXML
    private TableView<productModal> tableProduct;
    @FXML
    private TableColumn<productModal,String> ItemId;
    @FXML
    private TableColumn<productModal,String> Description;
    @FXML
    private TableColumn<productModal,Double> price;
    @FXML
    private TableColumn<productModal,Integer> qty;
    @FXML
    private TableColumn<productModal,Double> amount;
    @FXML
    private TextField txtItemId;
    @FXML
    private TextField txtDescription;
    @FXML
    private TextField txtPrice;
    @FXML
    private TextField txtQty;
    @FXML
    private TextField txtAmount;
    @FXML
    private TextField txtCompany;
    @FXML
    private TextField txtStock;
    @FXML
    private TextField txtType;
    @FXML
    private TextField txtSupplierNo;
    @FXML
    private TextField txtSupplierName;
    @FXML
    private TextField txtBalance;
    @FXML
    private TextField txtGRNno;
    @FXML
    private TextField txtDateAndTime;
    @FXML
    private TextField txtUser;
    @FXML
    private TextField txtGrAmount;
    @FXML
    private Button printButton;
    @FXML
    private Button addButton;
    @FXML
    private Button EditButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button clearButton;
    @FXML
    private Button addProductButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ArrayList<productModal> arr=new ArrayList<>();
        String getQuery="SELECT * FROM grn";
        ResultSet rsg=db.getData(getQuery);

        try {
            while (rsg.next()) {
                String productQuery="SELECT * FROM product where pid='"+rsg.getString(3)+"'";
                ResultSet rs=db.getData(productQuery);
                String grnNumber = rsg.getString(2);
                while (rs.next()) {
                    System.out.println(rs.getString(1) + "  " + rs.getString(2) + "  " + rs.getString(3) + "  " + rs.getString(4) + "  " + rs.getString(5) + "  " + rs.getString(6));
                    productModal pm = new productModal(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), Double.parseDouble(rs.getString(6)), Integer.parseInt(rs.getString(7)), Integer.parseInt(rs.getString(8)), Integer.parseInt(rs.getString(9)));
                    pm.setAmount(pm.getStock() * pm.getPrice());
                    arr.add(pm);

                }

        ObservableList<productModal> list= FXCollections.observableArrayList(arr);

        ItemId.setCellValueFactory(new PropertyValueFactory<productModal,String>("pid"));
        Description.setCellValueFactory(new PropertyValueFactory<productModal,String>("Description"));
        price.setCellValueFactory(new PropertyValueFactory<productModal,Double>("price"));
        qty.setCellValueFactory(new PropertyValueFactory<productModal,Integer>("stock"));
        amount.setCellValueFactory(new PropertyValueFactory<productModal,Double>("amount"));
        tableProduct.setItems(list);

        tableProduct.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                txtItemId.setText(tableProduct.getSelectionModel().getSelectedItem().getPid());
                txtDescription.setText(tableProduct.getSelectionModel().getSelectedItem().getDescription());
                txtCompany.setText(tableProduct.getSelectionModel().getSelectedItem().getCompany());
                txtPrice.setText(""+tableProduct.getSelectionModel().getSelectedItem().getPrice());
                txtQty.setText(""+tableProduct.getSelectionModel().getSelectedItem().getStock());
                txtAmount.setText(""+tableProduct.getSelectionModel().getSelectedItem().getAmount());
                txtType.setText(tableProduct.getSelectionModel().getSelectedItem().getType());
                txtStock.setText(""+tableProduct.getSelectionModel().getSelectedItem().getStock());
                String querySupplier="SELECT * FROM supplier WHERE sid='"+tableProduct.getSelectionModel().getSelectedItem().getSupplier()+"'";
                ResultSet rs1=db.getData(querySupplier);

                try {
                   //
                    while(rs1.next()) {
                        txtSupplierNo.setText(rs1.getString(1));
                        txtSupplierName.setText(rs1.getString(2));
                        txtBalance.setText(rs1.getString(5));
                       System.out.println(rs1.getString(1));
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }


              //  String grnQuery="SELECT * FROM grn ";


                        txtGRNno.setText(grnNumber);

                        String queryGRNLog="SELECT * FROM grnlog WHERE grnNo='"+grnNumber+"'";
                        ResultSet rs3=db.getData(queryGRNLog);
                try {

                        while (rs3.next()){
                            txtDateAndTime.setText(rs3.getString(2));
                            txtUser.setText(rs3.getString(3));
                            txtGrAmount.setText(rs3.getString(5));
                        }



                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }
        });


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Parent root;
                try {
                    root = FXMLLoader.load(getClass().getClassLoader().getResource("GUI/addGRN.fxml"), resources);
                    Stage stage = new Stage();
                    stage.setTitle("Add GRN");
                    stage.setScene(new Scene(root, 340, 308));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        EditButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Parent root;
                FXMLLoader loader=new FXMLLoader();
                loader.setLocation(getClass().getClassLoader().getResource("GUI/editGRN.fxml"));
                try {
                    loader.load();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                editGRNController editControl=loader.getController();
                editControl.setDet(txtItemId.getText(),txtGRNno.getText(),txtSupplierNo.getText(),txtQty.getText(),txtAmount.getText(),txtUser.getText());
                root=loader.getRoot();
                Stage stage = new Stage();
                stage.setTitle("My New Stage Title");
                stage.setScene(new Scene(root, 700, 700));
                stage.show();
            }
        });
        deleteButton.setOnAction(new EventHandler<ActionEvent>() {


            @Override
            public void handle(ActionEvent event) {
                String dId=txtGRNno.getText();
                String dltQuery="DELETE FROM grn WHERE sid='"+dId+"'";
                db.putData(dltQuery);
            }
        });
        clearButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                txtAmount.setText("");
                txtItemId.setText("");
                txtDescription.setText("");
                txtPrice.setText("");
                txtCompany.setText("");
                txtQty.setText("");
                txtDateAndTime.setText("");
                txtStock.setText("");
                txtType.setText("");
                txtSupplierNo.setText("");
                txtSupplierName.setText("");
                txtBalance.setText("");
                txtGRNno.setText("");
                txtUser.setText("");
                 /* String dltFull="DELETE * FROM grn";
                    db.putData(dltFull);*/
            }
        });
        addProductButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Parent root;
                try {
                    root = FXMLLoader.load(getClass().getClassLoader().getResource("GUI/addProduct.fxml"), resources);
                    Stage stage = new Stage();
                    stage.setTitle("Add new product");
                    stage.setScene(new Scene(root, 300, 480));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        printButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                try {
                    Connection connection = DB.con();
                    String xml = "GRNReceipt.jrxml";
                    JasperDesign jd= JRXmlLoader.load((getClass().getResourceAsStream(xml)));
                    Map<String, Object> params = new HashMap<String, Object>();
                    params.put("grnNo", txtGRNno.getText());
                    params.put("netAmo", txtGrAmount.getText());
                    params.put("date", txtDateAndTime.getText());
                    params.put("sName", txtSupplierName.getText());
                    JasperReport jr = JasperCompileManager.compileReport(jd);
                    JasperPrint jp = JasperFillManager.fillReport(jr, params,connection);
                    JasperViewer.viewReport(jp, false);
                    JasperPrintManager.printReport(jp, false);

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }

        });


    }
}
